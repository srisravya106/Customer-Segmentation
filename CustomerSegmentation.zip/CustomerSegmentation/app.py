import pandas as pd
import numpy as np
import sklearn
from flask import Markup
from flask import Flask, request, jsonify, render_template

data = pd.read_csv("data.csv", encoding= 'unicode_escape')

data = data[~data['CustomerID'].isnull()]
#print(data.head())
data = data.loc[data["Quantity"]>0]

#print(data.shape)
data['CustomerID'] = data['CustomerID'].astype('int')
#print(data.head())

data["InvoiceDate"] = pd.to_datetime(data["InvoiceDate"])
#print(data.info())

data["Sale"] = data.Quantity * data.UnitPrice
#print(data.head())

monetary = data.groupby("CustomerID").Sale.sum()
monetary = monetary.reset_index()
#print(monetary.head())

frequency = data.groupby("CustomerID").InvoiceNo.count()
frequency = frequency.reset_index()
#print(frequency.head())

LastDate = max(data.InvoiceDate)
LasDate = LastDate + pd.DateOffset(days = 1)
data["Diff"] = LastDate - data.InvoiceDate
data["Diff"] = data["Diff"].dt.days
recency = data.groupby("CustomerID").Diff.min()
recency = recency.reset_index()
#print(recency.head())

RMF = monetary.merge(frequency, on = "CustomerID")
RMF = RMF.merge(recency, on = "CustomerID")
RMF.columns = ["CustomerID", "Monetary", "Frequency", "Recency"]
#type(RMF)
RMFOfUserId = RMF
#print(RMFOfUserId.head())

def RMFValueByID(customerId):
    num = RMFOfUserId['CustomerID'].astype(int)
    return RMFOfUserId.loc[num == customerId]

#customerId = 12346.0
#print(RMFValueByID(customerId))

#from joblib import load
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')



@app.route('/y_predict',methods=['POST'])
def y_predict():
    '''
    For rendering results on HTML GUI
    '''
   
    test = [int(x) for x in request.form.values()]
    #print("..........")
    #print(type(test[0]))
    x_test = test[0]
    
    prediction = RMFValueByID(x_test)
    pred = prediction.to_string()
    list1 =[]
    list1 = pred.split()
    print(list1)
    #print(val)
    print(".....")
    #print(result)
    #pred=Markup("Col"+str(col)+"<br>Values"+str(val))
    '''print(prediction[1])
    print(prediction[2]) 
    print(prediction[3])
    print(prediction[4])
    print(prediction[5])
    print(prediction[6])
    print(prediction[7])
    print(prediction[8])'''
    list2 = []
    if prediction.empty:
        return render_template('index.html',CustomerId = list2,Recency=list2,Frequency=list2,Monetary=list2)
    return render_template('index.html',CustomerId = list1[5],Recency=list1[6],Frequency=list1[7],Monetary=list1[8])

@app.route('/predict_api',methods=['POST'])
def predict_api():
    '''
    For direct API calls trought request
    '''
    data = request.get_json(force=True)
    prediction = model.y_predict()
    output = prediction[0]
    return jsonify(output)

if __name__ == "__main__":
    app.run(debug=True)